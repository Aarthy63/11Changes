var express = require('express');
let jwt=require('../adminmiddleware/adminjwt')
var router = express.Router();

const registerlistcontroller = require('../controlleradmin/registerlistcontroller')
const adminlogincontroller=require('../controlleradmin/adminlogincontroller')
const adminchangepassword=require('../controlleradmin/adminpasswordchange')
const adminchangepattern=require('../controlleradmin/adminpatterncontroller')
const adminforgoatpassword=require('../controlleradmin/forgotpassword')







//use router list
router.post('/adminlogin',adminlogincontroller.handleAdminlogin);
router.post('/adminlogin/twoFactorGetCode',adminlogincontroller.generateTwoFactorCode)
router.post('/adminlogin/twoFactorVerify',adminlogincontroller.loginTwoFactorVerify)
router.post('/adminlogin/disableTwoFactor',adminlogincontroller.disableTwoFactorAuthentication)
router.get('/registerlist',jwt.authorization,registerlistcontroller.handleregisterlist);
router.post('/changepassword',jwt.authorization,adminchangepassword.adminpasswordchange)
router.post('/oldPattern',adminchangepattern.handleOldPattern)
router.post('/newPattern',adminchangepattern.updatePattern)
router.post('/forgetPassword/verifyEmail',adminforgoatpassword.verifyEmail)
router.post('/login/loginTwoFactorVerify',adminforgoatpassword.adminLoginTwoFactorVerify)
router.post('/setpassword',adminforgoatpassword.setpassword)
router.post('/setpattern',adminforgoatpassword.setpattern)




module.exports=router