const adminschema=require('../modelsadmin/adminschema')
const speakEasy = require('@levminer/speakeasy')
const qrCode = require('qrcode')
const bcrypt=require('bcrypt')


exports.verifyEmail = async (req, res) => {
    // console.log(req.body);
    try {
        const { email } = req.body
        const adminData = await adminschema.findOne({ email })
        if (!adminData) {
            return res.status(401).json({ message: 'User Not Found' })
        }
        res.status(200).json({ message: 'Email Verified', adminData })
    } catch (err) {
        res.status(500).json({ message: 'Internal Server Error', error: err.message })
    }

}


exports.adminLoginTwoFactorVerify = async (req, res) => {
    // console.log(req.body);
    try {
        const { id, token } = req.body
        console.log(id, token);
        const getUser = await adminschema.findOne({ _id: id })

        let tokenValidates = speakEasy.totp.verify({
            secret: getUser.secret.base32,
            encoding: "base32",
            token,
        })

        let qrCodeVerify = speakEasy.totp.verify({
            secret: getUser.secret.ascii,
            encoding: 'ascii',
            token
        })
        if (!qrCodeVerify) {
            return res.status(401).json({ message: 'Authentication Invalid' })
        }
        if (!tokenValidates) {
            return res.status(401).json({ message: 'Authentication Invalid Token' })
        }
        res.status(200).json({ message: 'Authentication Verified', })

    } catch (err) {
        res.status(500).json({ message: 'Error Generating Authencation verify ', error: err.message })
    }
}



exports.setpassword = async (req, res) => {
    // console.log(req.body.password);
    try {
        const { password, id } = req.body
        const changePassword = await bcrypt.hash(password, 10)
        await adminschema.updateOne({ _id: id }, { $set: { password:changePassword } })
        res.status(200).json({ message: 'Password Updated' })
    } catch (err) {
        res.status(500).json({ message: "Internal Error", error: err.message })
    }
}




exports.setpattern = async (req, res) => {
    const { newpattern, id } = req.body;
    const patt = JSON.stringify(newpattern);

    try {
        const exisistPattern = await adminschema.findOne({
            _id: id,
        });

        if (patt === exisistPattern.pattern) {
            return res.status(409).json({ message: "Already exisistPattern " });
        }
        await adminschema.updateOne({ _id: id }, { $set: { pattern: patt } });
        res.status(200).json({ message: "NewPattern Updated" });
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
};