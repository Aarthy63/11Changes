const userschema=require('../modelsadmin/adminschema')


exports.handleregisterlist= async (req, res) => {
    try {
        const getAllUser = await userschema.find()
        console.log(getAllUser);
        res.status(200).json({ msg: 'data recieved successfully', getAllUser })
        
    }
    catch (error) {
        res.status(401).json({ message: 'error in registerlist ' })
    }

}