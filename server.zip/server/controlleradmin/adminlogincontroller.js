const adminschema = require('../modelsadmin/adminschema')
const jwt=require('jsonwebtoken');
const speakEasy = require('@levminer/speakeasy')
const bcrypt = require('bcrypt')
const qrCode = require('qrcode')


exports.handleAdminlogin = async (req, res) => {
    const { email, password, pattern } = req.body;
    const loginAdmin = await adminschema.findOne({
      email: email,
    });
    // console.log(loginAdmin.authVerify);
    if (!loginAdmin) res.status(404).json({ message: "Please enter Correct Email" });
  const patternverify = JSON.stringify(pattern);
  try {
    const decodedPwd = await bcrypt.compare(password, loginAdmin.password)
    if (!decodedPwd) {
      return res.status(404).json({ message: "please enter correct password" });
    } else if (loginAdmin.pattern !== patternverify) {
      return res.status(404).json({ message: "please enter correct pattern" });
    } else 
    {
      const adminId=loginAdmin._id 
      const token = jwt.sign({  adminId:loginAdmin._id }, 'secretKey', { expiresIn: "1h" });
      return res.status(200).json({ message: `Admin Login sucesssfully 
       `, adminId,token,authVerify:loginAdmin.authVerify });
    }
  } catch (error) {
    console.log(error,'adminlogin error');
  }
};


exports. generateTwoFactorCode = async (req, res) => {

  try {
      const { id } = req.body
      console.log(id)
      // checking Already Verified User
      const secretCode = speakEasy.generateSecret()

      await adminschema.updateOne({ _id: id }, { $set: { temp_secret: secretCode } })
      const twoFactorAuthData = await adminschema.findOne({ _id: id })

      // generating QrCode Img Src
      qrCode.toDataURL(twoFactorAuthData.temp_secret.otpauth_url, function (err, data) {
          if (err) {
              return res.status(404).json({ message: 'Generating QrCode Error' })
          }
          res.status(200).json({ message: 'Generate TwoFactorAuth', authCode: secretCode.base32, qrCodeImgSrc: data, twoFactorAuthData })
      })

  } catch (error) {
      res.status(500).json({ message: 'Error Generating TwoFactor Secret', error: error.message })
  }
}



exports.loginTwoFactorVerify = async (req, res) => {
  try {
      const { id, token } = req.body
      console.log(id, token);
      const getUser = await adminschema.findOne({ _id: id })
      const { base32: secret } = getUser.temp_secret

      let tokenValidates = speakEasy.totp.verify({
          secret,
          encoding: "base32",
          token,
      })

      let qrCodeVerify = speakEasy.totp.verify({
          secret: getUser.temp_secret.ascii,
          encoding: 'ascii',
          token
      })
      if (!qrCodeVerify) {
          return res.status(401).json({ message: 'Authentication Invalid' })
      }
      if (!tokenValidates) {
          return res.status(401).json({ message: 'Authentication Invalid Token' })
      }

      await adminschema.updateOne({ _id: id }, { $set: { temp_secret: null, secret: getUser.temp_secret, authVerify: true } })
      const updateUser = await adminschema.findOne({ _id: id })
      res.status(200).json({ message: 'Authentication Verified', twoFactorAuth: updateUser.twoFactorAuth, })

  } catch (err) {
      res.status(500).json({ message: 'Error Generating Authencation verify ', error: err.message })
  }
}



exports. disableTwoFactorAuthentication = async (req, res) => {
  try {
      const { id } = req.body
      await adminschema.updateOne({ _id: id }, { $set: { secret: null, authVerify: false } })
      res.status(200).json({ message: 'Disabled Your Authetication' })

  } catch (error) {
      res.status(500).json({ message: 'Error Disable Your Authentication', error: error.message })
  }
}
   




