const adminschema=require('../modelsadmin/adminschema')

exports.handleOldPattern = async (req, res) => {
    const pattern = JSON.stringify(req.body.oldpattern);
    try {
        const handleOldPassword = await adminschema.findOne({
            _id:req.body.adminId
        })
        if (pattern === handleOldPassword.pattern) {
            return res.status(200).json({ message: 'pattern valid successfully' })
        }
        else {
            return res.status(401).json({ message: ' invalid pattern' })
        }
    }
    catch (error) {
        console.log(error,'admin changepattern error');
    }
}


exports.updatePattern = async (req, res) => {
    // console.log(req.body);
    const { newpattern, adminId } = req.body;
    const pattern = JSON.stringify(newpattern);

    try {
        const exisistPattern = await adminschema.findOne({
            _id: adminId,
        });

        if (pattern === exisistPattern.pattern) {
            return res.status(409).json({ message: "Already exisist Pattern " });
        }
        await adminschema.updateOne({ _id: adminId },
             { $set: { pattern: pattern } });
        res.status(200).json({ message: "NewPattern Updated sucessfully" });
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
};